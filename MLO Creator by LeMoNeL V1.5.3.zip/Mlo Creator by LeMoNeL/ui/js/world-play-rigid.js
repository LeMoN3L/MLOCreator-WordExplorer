// Local, contact-activated preview physics. Untouched props keep their authored pose.
(function(M){'use strict';const P=M.WorldPlayPhysics;
 const RADIUS=2,GROUND_RADIUS=5;
 let enginePromise=null;
 async function engine(){if(M.WorldPlayRapier)return M.WorldPlayRapier;if(!enginePromise)enginePromise=import('./vendor/rapier/rapier.js').then(async module=>{await module.init();M.WorldPlayRapier=module;return module;}).catch(e=>{enginePromise=null;throw e;});return enginePromise;}
 const vec=a=>({x:a[0],y:a[1],z:a[2]}),array=p=>[p.x,p.y,p.z],quat=q=>({x:q[0],y:q[1],z:q[2],w:q[3]}),qarray=q=>[q.x,q.y,q.z,q.w];
 const product=(a,b)=>[a[3]*b[0]+a[0]*b[3]+a[1]*b[2]-a[2]*b[1],a[3]*b[1]-a[0]*b[2]+a[1]*b[3]+a[2]*b[0],a[3]*b[2]+a[0]*b[1]-a[1]*b[0]+a[2]*b[3],a[3]*b[3]-a[0]*b[0]-a[1]*b[1]-a[2]*b[2]];
 function bounds(index){return {min:Array.from(index.nodes.slice(0,3)),max:Array.from(index.nodes.slice(3,6))};}
 function distance(box,pos,height=1.76){if(!box)return Infinity;const mn=box.min,mx=box.max,dx=Math.max(mn[0]-pos[0],0,pos[0]-mx[0]),dy=Math.max(mn[1]-pos[1],0,pos[1]-mx[1]),dz=Math.max(mn[2]-pos[2]-height,0,pos[2]-mx[2]);return Math.hypot(dx,dy,dz);}
 M.createWorldPlayRigid=function(C){
  let R=null,world=null,origin=[0,0,0],index=null,ground=[],groundAt=null,groundIndex=null,groundTriangles=0,doorRows=[],controller=null,actor=null,actorCollider=null,nonce=0,center=null,stepCount=0,physicsMs=0;
  const records=new Map(),snapshots=new Map(),moving=[],characterMoving=[],doorBodies=new Map();
  const local=p=>p.map((n,a)=>n-origin[a]),global=p=>p.map((n,a)=>n+origin[a]);
  function lists(){moving.length=characterMoving.length=0;for(const d of records.values()){moving.push(d.moving);if(!d.dynamic)characterMoving.push(d.moving);}}
  function shape(row){let desc=R.ColliderDesc.convexHull(row.localPoints);if(!desc){const mn=row.localMin,mx=row.localMax;desc=R.ColliderDesc.cuboid(...mn.map((n,a)=>Math.max(.02,(mx[a]-n)*.5))).setTranslation(...mn.map((n,a)=>(n+mx[a])*.5));}return desc.setFriction(.55).setRestitution(.03).setMass(row.mass);}
  function render(d){const renderer=C.renderer();if(!renderer)return;renderer.playEntities=renderer.playEntities||new Map();const e=C.entities.get(d.id)||d.entity,off=C.offsets.get(d.id)||[0,0,0],min=[Infinity,Infinity,Infinity],max=[-Infinity,-Infinity,-Infinity];
   for(let k=0;k<8;k++){const p=P.rotateQ(d.localMin.map((n,a)=>k&(1<<a)?d.localMax[a]:n),d.currentRot);for(let a=0;a<3;a++){min[a]=Math.min(min[a],p[a]+d.currentPos[a]-off[a]);max[a]=Math.max(max[a],p[a]+d.currentPos[a]-off[a]);}}
   d.moving.bounds={min:min.map((n,a)=>n+off[a]),max:max.map((n,a)=>n+off[a])};renderer.playEntities.set(d.id,{...e,pos:d.currentPos.map((n,a)=>n-off[a]),rot:d.currentRot,min,max});renderer.transformRevision=(renderer.transformRevision||0)+1;
   const now=performance.now();if(!renderer.playPropShadowAt||now-renderer.playPropShadowAt>140){renderer.playPropShadowAt=now;renderer.environment?.invalidate();}
  }
  function pose(d,pos,rotation){const changed=pos.some((n,a)=>Math.abs(n-d.currentPos[a])>.0001)||rotation.some((n,a)=>Math.abs(n-d.currentRot[a])>.0001);d.currentPos=pos;d.currentRot=rotation;d.moving.pose={from:d.pos,to:pos,rotation:product(rotation,[-d.rot[0],-d.rot[1],-d.rot[2],d.rot[3]])};if(changed)render(d);}
  function sync(d){if(d.body)pose(d,global(array(d.body.translation())),qarray(d.body.rotation()));}
  function release(d){if(!d.body)return;sync(d);world.removeRigidBody(d.body);d.body=null;d.dynamic=false;}
  function body(d){if(!d.body){d.body=world.createRigidBody(R.RigidBodyDesc.fixed().setTranslation(...local(d.currentPos)).setRotation(quat(d.currentRot)));world.createCollider(shape(d),d.body);}return d.body;}
  function nearby(player,input){center=player.pos.slice();let changed=false,active=[...records.values()].filter(d=>d.dynamic).length;const length=Math.hypot(...input.move),ahead=player.pos.slice();if(length){ahead[0]+=input.move[0]/length*.08;ahead[1]+=input.move[1]/length*.08;}
   for(const d of records.values()){
    // Distance is measured from the player's capsule to the current collision
    // bounds, not from the tile anchor or a potentially distant model origin.
    if(distance(d.moving.bounds,player.pos,player.height)>RADIUS){if(d.body){release(d);changed=true;}continue;}
    if(!d.dynamic&&active<8&&length&&!player.vault&&P.contacts(d.moving,ahead,player.radius??.29,player.height??1.76,.025).some(q=>Math.abs(q.normal[2])<.7)){
     const b=body(d);b.setBodyType(R.RigidBodyType.Dynamic,true);b.setLinearDamping(.35);b.setAngularDamping(.6);b.enableCcd(true);d.dynamic=true;active++;changed=true;
    }
   }
   if(changed)lists();
  }
  // Rapier only needs terrain around a contacted prop. The larger streamed BVH
  // remains available for walking, vaulting, camera clearance and safe spawning.
  function prepareGround(player){if(groundIndex===index&&groundAt&&Math.hypot(...player.pos.map((n,a)=>n-groundAt[a]))<1.5)return;const p=player.pos,mn=[p[0]-GROUND_RADIUS,p[1]-GROUND_RADIUS,p[2]-3],mx=[p[0]+GROUND_RADIUS,p[1]+GROUND_RADIUS,p[2]+5],points=[];
   P.visit(index,mn,mx,(t,source)=>{const a=source.points,i=t*9;for(let axis=0;axis<3;axis++)if(Math.min(a[i+axis],a[i+3+axis],a[i+6+axis])>mx[axis]||Math.max(a[i+axis],a[i+3+axis],a[i+6+axis])<mn[axis])return;for(let k=0;k<9;k++)points.push(a[i+k]-origin[k%3]);});
   const created=[];try{for(let start=0;start<points.length;start+=2048*9){const data=new Float32Array(points.slice(start,start+2048*9)),ids=Uint32Array.from({length:data.length/3},(_,i)=>i),c=world.createCollider(R.ColliderDesc.trimesh(data,ids,R.TriMeshFlags.FIX_INTERNAL_EDGES).setFriction(.65).setRestitution(0));created.push(c);}
    for(const old of ground)world.removeCollider(old,false);ground=created;groundAt=p.slice();groundIndex=index;groundTriangles=points.length/9;
   }catch(e){for(const c of created)world.removeCollider(c,false);throw e;}
  }
  function obstacles(player,hinges){const keep=new Set();for(const d of records.values())if(distance(d.moving.bounds,player.pos,player.height)<=RADIUS){body(d);keep.add(d.id);}
   for(const row of doorRows){if(distance(row.bounds||{min:row.min,max:row.max},player.pos,player.height)>3)continue;let d=doorBodies.get(row.id);if(!d){const inverse=[-row.rot[0],-row.rot[1],-row.rot[2],row.rot[3]],points=row.index.points,data=new Float32Array(points.length);for(let i=0;i<points.length;i+=3)data.set(P.rotateQ([points[i]-row.pos[0],points[i+1]-row.pos[1],points[i+2]-row.pos[2]],inverse),i);const desc=R.ColliderDesc.convexHull(data);if(!desc)continue;const b=world.createRigidBody(R.RigidBodyDesc.kinematicPositionBased().setTranslation(...local(row.pos)).setRotation(quat(row.rot)));world.createCollider(desc.setFriction(.6),b);d={body:b};doorBodies.set(row.id,d);}keep.add('door:'+row.id);const hinge=hinges.find(h=>h.id===row.id);if(hinge){const p=P.turn(hinge.pos,hinge.hinge,hinge.angle),q=product([0,0,Math.sin(hinge.angle/2),Math.cos(hinge.angle/2)],hinge.rot);d.body.setNextKinematicTranslation(vec(local(p)));d.body.setNextKinematicRotation(quat(q));}}
   for(const [id,d]of doorBodies)if(!keep.has('door:'+id)){world.removeRigidBody(d.body);doorBodies.delete(id);}
  }
  async function prepare(source,rows,doors,at){const token=++nonce,physics=await engine();if(token!==nonce)return false;R=physics;if(!world){origin=at.slice();world=new R.World({x:0,y:0,z:-18});world.integrationParameters.numSolverIterations=6;}index=source;doorRows=doors||[];groundIndex=null;center=at.slice();const ids=new Set((rows||[]).map(r=>r.id));
   for(const [id,d]of records)if(!ids.has(id)){release(d);snapshots.set(id,{stamp:d.stamp,pos:d.currentPos,rot:d.currentRot});records.delete(id);}
   for(const row of rows||[]){const stamp=JSON.stringify([row.pos,row.rot,row.flags,row.mass,row.localPoints.length]),old=records.get(row.id);if(old?.stamp===stamp){old.index=row.index;old.moving.base=row.index;continue;}if(old)release(old);const saved=snapshots.get(row.id),initial=saved?.stamp===stamp?saved:row,d={...row,stamp,body:null,dynamic:false,currentPos:row.pos.slice(),currentRot:row.rot.slice(),moving:{base:row.index,tag:'dynamic:'+row.id,bounds:bounds(row.index),pose:{from:row.pos,to:row.pos,rotation:[0,0,0,1]}}};records.set(row.id,d);if(initial!==row)pose(d,initial.pos,initial.rot);}
   while(snapshots.size>512){const id=snapshots.keys().next().value;snapshots.delete(id);C.renderer()?.playEntities?.delete(id);}lists();return true;
  }
  function beginCharacter(player,input){if(world)nearby(player,input);}
  function moveCharacter(player,before,dt,hinges){if(!world)return;const started=performance.now();nearby(player,{move:[player.pos[0]-before[0],player.pos[1]-before[1]]});const active=[...records.values()].filter(d=>d.dynamic&&d.body);if(!active.length){physicsMs=0;return;}prepareGround(player);obstacles(player,hinges);
   if(!actor){actor=world.createRigidBody(R.RigidBodyDesc.kinematicPositionBased().setTranslation(...local([before[0],before[1],before[2]+player.height*.5])));actorCollider=world.createCollider(R.ColliderDesc.capsule(player.height*.5-player.radius,player.radius).setRotation({x:Math.SQRT1_2,y:0,z:0,w:Math.SQRT1_2}).setFriction(.5),actor);controller=world.createCharacterController(.006);controller.setUp({x:0,y:0,z:1});controller.setApplyImpulsesToDynamicBodies(true);controller.setCharacterMass(80);controller.enableAutostep(.32,.15,false);controller.enableSnapToGround(.13);controller.setMaxSlopeClimbAngle(Math.acos(.64));controller.setMinSlopeSlideAngle(Math.acos(.6));}
   const capsuleCenter=local([before[0],before[1],before[2]+player.height*.5]);actor.setTranslation(vec(capsuleCenter),false);world.propagateModifiedBodyPositionsToColliders();
   const desired=player.pos.map((n,a)=>n-before[a]);controller.computeColliderMovement(actorCollider,vec(desired));const delta=array(controller.computedMovement());player.pos=before.map((n,a)=>n+delta[a]);if(player.vault&&Math.hypot(...delta.map((n,a)=>n-desired[a]))>.03)player.vault=null;if(player.vel[2]<=0&&controller.computedGrounded()){player.grounded=true;player.vel[2]=0;}
   for(let i=0;i<controller.numComputedCollisions();i++){const collision=controller.computedCollision(i),b=collision?.collider?.parent();if(b?.isDynamic())for(const d of active)if(d.body.handle===b.handle){player.pushing=d.id;break;}}
   actor.setNextKinematicTranslation(vec(local([player.pos[0],player.pos[1],player.pos[2]+player.height*.5])));world.timestep=dt;world.step();stepCount++;let settled=false;for(const d of active){sync(d);if(d.body.isSleeping()){d.body.setBodyType(R.RigidBodyType.Fixed,false);d.dynamic=false;settled=true;}}if(settled)lists();physicsMs=performance.now()-started;
  }
  function reset(){nonce++;if(world)world.free();world=null;ground=[];groundAt=groundIndex=index=null;doorRows=[];doorBodies.clear();actor=null;actorCollider=null;controller=null;center=null;groundTriangles=stepCount=physicsMs=0;records.clear();snapshots.clear();moving.length=characterMoving.length=0;}
  return {prepare,beginCharacter,moveCharacter,reset,collisions:()=>moving,characterCollisions:()=>characterMoving,getState:()=>({engine:'Rapier 0.19.3',radius:RADIUS,center:center?.slice()||null,candidates:records.size,bodies:[...records.values()].filter(d=>d.body).length,awake:[...records.values()].filter(d=>d.dynamic&&d.body&&!d.body.isSleeping()).length,steps:stepCount,groundTriangles,physicsMs,poses:[...records.values()].map(d=>({id:d.id,pos:d.currentPos,rot:d.currentRot,mass:d.mass,active:d.dynamic}))})};
 };
})(typeof window==='undefined'?globalThis.MLO:window.MLO);
