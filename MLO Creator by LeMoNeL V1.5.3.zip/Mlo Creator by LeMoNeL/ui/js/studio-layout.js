﻿// Dock existing editor controls without changing project or export data.
(function(M){
'use strict';
let queued=false, selection=null, lightControls=null;
function sync(){
 queued=false;const S=M.Model.state, left=document.getElementById('left'),right=document.getElementById('right'),assets=document.getElementById('studio-assets');
 const active=S.project&&S.project.kind==='import'&&S.tab==='build', fitting=active&&S.shellTool==='fit',lighting=active&&S.shellTool==='light';
 document.body.classList.toggle('studio-assets-open',fitting||lighting);
 document.body.classList.toggle('studio-build',active);
 const library=left.querySelector(lighting?'.studio-light-library':'.studio-library');
 if(library&&lighting)assets.replaceChildren(library);
 if(library&&!lighting){
  const heading=library.querySelector('.h'), rows=[...library.children].filter(n=>n.classList.contains('row'));
  const tabs=rows.find(n=>n.querySelector('.seg')),search=rows.find(n=>n.querySelector('input[data-fitfilter]'));
  const header=M.el('div',{class:'studio-asset-header'});
  if(heading)header.append(heading);if(tabs)header.append(tabs);if(search)header.append(search);
  library.prepend(header); assets.replaceChildren(library);
 }
 if(active&&!fitting&&!lighting){
  if(!assets.querySelector('.studio-launcher')){assets.replaceChildren();const title=M.el('b',null,'Asset Browser');assets.append(M.el('div',{class:'studio-launcher'},title,...[['window','Windows'],['door','Doors'],['frame','Frames']].map(([kind,label])=>M.el('button',{class:'btn sm',onclick:()=>{S.fitCat=kind;M.App.setTool('fit');}},label))));}
 }
 const lightPanel=left.querySelector('.interior-light-controls');if(lightPanel){if(lightControls&&lightControls!==lightPanel)lightControls.remove();lightControls=lightPanel;}
 if(lighting&&lightControls){if(!right.contains(lightControls))right.prepend(lightControls);}else if(lightControls){lightControls.remove();lightControls=null;}
 const fresh=left.querySelector('.studio-selection');if(fresh){
 selection=fresh;
 const title=fresh.querySelector('.h');
 const rows=[...fresh.children].filter(n=>n.classList.contains('row')&&n.querySelector('input[type=number]'));
 const rowByLabel=text=>rows.find(n=>n.querySelector('label')?.textContent===text);
 const transform=M.el('div',{class:'studio-transform'},M.el('div',{class:'studio-section-heading'},'⌄  Transform'),M.el('div',{class:'studio-subheading'},'Position'));
 ['Centre x','Centre y','Bottom'].forEach((text,i)=>{const row=rowByLabel(text);if(row){row.querySelector('label').textContent=['X','Y','Z'][i];transform.append(row);}});
 transform.append(M.el('div',{class:'studio-subheading'},'Size'));
 ['Width','Height','Depth'].forEach(text=>{const row=rowByLabel(text);if(row)transform.append(row);});
 if(title)title.after(transform);
}
 if(fitting&&M.FitModels.sel&&selection){if(!right.contains(selection))right.prepend(selection);}
 else {if(selection&&selection.parentNode)selection.remove();selection=null;}
 const heading=left.querySelector('.studio-workflow-title');
 if(!heading&&active)left.prepend(M.el('div',{class:'studio-workflow-title'},M.el('span',null,'WORKFLOW'),M.el('span',{class:'note'},'Build your interior')));
}
function schedule(){if(queued)return;queued=true;requestAnimationFrame(sync);}
window.addEventListener('load',()=>{
 const root=document.documentElement;
 const minHeight=160, maxHeight=()=>Math.max(minHeight,Math.floor(window.innerHeight*.65));
 const setHeight=value=>{const height=Math.max(minHeight,Math.min(maxHeight(),value));root.style.setProperty('--asset-height',height+'px');return height;};
 let stored=280;try{const n=Number(localStorage.getItem('mlo.assetBrowserHeight'));if(n>0)stored=n;}catch(e){}setHeight(stored);
 const handle=M.el('div',{id:'studio-asset-resizer',title:'Drag up or down to resize Asset Browser',role:'separator','aria-orientation':'horizontal','aria-label':'Resize Asset Browser',tabindex:0});
 document.getElementById('app').append(handle);
 let dragging=false;
 const stop=()=>{if(!dragging)return;dragging=false;handle.classList.remove('dragging');document.body.classList.remove('studio-resizing');try{localStorage.setItem('mlo.assetBrowserHeight',parseFloat(root.style.getPropertyValue('--asset-height')));}catch(e){}};
 handle.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();e.stopPropagation();dragging=true;handle.classList.add('dragging');document.body.classList.add('studio-resizing');handle.setPointerCapture(e.pointerId);});
 handle.addEventListener('pointermove',e=>{if(dragging){e.preventDefault();setHeight(window.innerHeight-e.clientY-27);}});
 handle.addEventListener('pointerup',stop);handle.addEventListener('pointercancel',stop);handle.addEventListener('lostpointercapture',stop);
 handle.addEventListener('keydown',e=>{if(e.key==='ArrowUp'||e.key==='ArrowDown'){e.preventDefault();setHeight(parseFloat(root.style.getPropertyValue('--asset-height'))+(e.key==='ArrowUp'?24:-24));try{localStorage.setItem('mlo.assetBrowserHeight',parseFloat(root.style.getPropertyValue('--asset-height')));}catch(err){}}});
 window.addEventListener('resize',()=>setHeight(parseFloat(root.style.getPropertyValue('--asset-height'))||280));


 const panelWidth=()=>parseFloat(getComputedStyle(root).getPropertyValue('--studio-right'))||286;
 const setWidth=value=>{
  const leftWidth=parseFloat(getComputedStyle(root).getPropertyValue('--studio-left'))||258;
  const max=Math.max(220,Math.min(560,window.innerWidth-leftWidth-340));
  const width=Math.max(220,Math.min(max,value));root.style.setProperty('--studio-right',width+'px');return width;
 };
 try{const saved=Number(localStorage.getItem('mlo.inspectorWidth'));if(saved>0)setWidth(saved);}catch(e){}
 const sideHandle=M.el('div',{id:'studio-inspector-resizer',title:'Drag left or right to resize the properties panel',role:'separator','aria-orientation':'vertical','aria-label':'Resize properties panel',tabindex:0});
 document.getElementById('app').append(sideHandle);
 let sideDragging=false;
 const saveWidth=()=>{try{localStorage.setItem('mlo.inspectorWidth',String(panelWidth()));}catch(e){}};
 const stopSide=()=>{if(!sideDragging)return;sideDragging=false;sideHandle.classList.remove('dragging');document.body.classList.remove('studio-resizing-side');saveWidth();};
 sideHandle.addEventListener('pointerdown',e=>{if(e.button!==0)return;e.preventDefault();e.stopPropagation();sideDragging=true;sideHandle.classList.add('dragging');document.body.classList.add('studio-resizing-side');sideHandle.setPointerCapture(e.pointerId);});
 sideHandle.addEventListener('pointermove',e=>{if(sideDragging){e.preventDefault();setWidth(window.innerWidth-e.clientX);}});
 ['pointerup','pointercancel','lostpointercapture'].forEach(event=>sideHandle.addEventListener(event,stopSide));
 sideHandle.addEventListener('keydown',e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();setWidth(panelWidth()+(e.key==='ArrowLeft'?20:-20));saveWidth();}});
 window.addEventListener('resize',()=>setWidth(panelWidth()));
 new MutationObserver(schedule).observe(document.getElementById('left'),{childList:true,subtree:true});
 new MutationObserver(schedule).observe(document.getElementById('right'),{childList:true});
 ['project','change','tooloptions','cutsel','shellsel'].forEach(event=>M.Model.bus.on(event,schedule));schedule();
});
})(window.MLO);
