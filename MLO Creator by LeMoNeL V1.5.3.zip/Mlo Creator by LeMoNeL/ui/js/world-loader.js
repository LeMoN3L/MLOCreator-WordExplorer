﻿(function(M){'use strict';
 class WorldAssetLoader{
  constructor(parallelism){this.tasks=new Map();this.id=0;this.workers=[];this.next=0;this.parallelism=parallelism||Math.max(2,Math.min(4,(navigator.hardwareConcurrency||4)-2));this.token=document.querySelector('meta[name="mlo-token"]')?.content||'';for(let i=0;i<this.parallelism;i++){const w=new Worker('js/world-worker.js');w.onmessage=({data:m})=>{const task=this.tasks.get(m.id);this.tasks.delete(m.id);if(task)m.error?task.reject(Object.assign(Error(m.error),{name:m.name||'Error'})):task.resolve(m.data);};w.onerror=event=>{for(const [id,t]of this.tasks)if(t.worker===w){t.reject(Error(event.message||'World loader failed'));this.tasks.delete(id);}};this.workers.push(w);}}
  cancelWhere(predicate=()=>true){for(const [id,t]of this.tasks)if(predicate(t.body)){this.tasks.delete(id);t.worker.postMessage({cancel:id});t.reject(Object.assign(Error('World request superseded'),{name:'AbortError'}));}}
  load(body){return new Promise((resolve,reject)=>{const id=++this.id,worker=this.workers[this.next++%this.workers.length];this.tasks.set(id,{resolve,reject,worker,body});worker.postMessage({id,body,token:this.token});});}
 }
 M.WorldAssetLoader=WorldAssetLoader;
})(window.MLO);
