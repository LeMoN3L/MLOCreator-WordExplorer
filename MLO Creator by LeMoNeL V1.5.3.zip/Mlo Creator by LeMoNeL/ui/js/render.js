﻿// Small WebGL1 renderer: lit textured batches, a grid, translucent overlays, and an orbit camera. Z is up.
window.MLO = window.MLO || {};
(function (M) {
    'use strict';
    const mat4 = M.mat4, TEX = M.TEX;

    function Camera() {
        this.target = [0, 0, 0]; this.dist = 20; this.yaw = 225 * Math.PI / 180; this.pitch = 50 * Math.PI / 180; this.fov = 45 * Math.PI / 180;
        this.vp = mat4.create(); this.inv = mat4.create(); this.view = mat4.create(); this.proj = mat4.create(); this.aspect = 1;
    }
    Camera.prototype.eye = function () {
        const cp = Math.cos(this.pitch);
        return [this.target[0] + this.dist * cp * Math.cos(this.yaw), this.target[1] + this.dist * cp * Math.sin(this.yaw), this.target[2] + this.dist * Math.sin(this.pitch)];
    };
    Camera.prototype.update = function (aspect) {
        this.aspect = aspect;
        mat4.perspective(this.proj, this.fov, aspect, Math.max(0.08, this.dist * 0.02), this.dist * 30 + 400);
        mat4.lookAt(this.view, this.eye(), this.target, [0, 0, 1]);
        mat4.mul(this.vp, this.proj, this.view);
        mat4.invert(this.inv, this.vp);
    };
    Camera.prototype.ray = function (nx, ny) {
        const un = (z) => {
            const x = nx, y = ny, i = this.inv;
            const ox = i[0] * x + i[4] * y + i[8] * z + i[12], oy = i[1] * x + i[5] * y + i[9] * z + i[13], oz = i[2] * x + i[6] * y + i[10] * z + i[14], ow = i[3] * x + i[7] * y + i[11] * z + i[15];
            return [ox / ow, oy / ow, oz / ow];
        };
        const a = un(-1), b = un(1), d = [b[0] - a[0], b[1] - a[1], b[2] - a[2]], l = Math.hypot(d[0], d[1], d[2]);
        return { o: this.eye(), d: [d[0] / l, d[1] / l, d[2] / l] };
    };
    Camera.prototype.project = function (p, w, h) {
        const v = this.vp, x = v[0] * p[0] + v[4] * p[1] + v[8] * p[2] + v[12], y = v[1] * p[0] + v[5] * p[1] + v[9] * p[2] + v[13], ww = v[3] * p[0] + v[7] * p[1] + v[11] * p[2] + v[15];
        if (ww <= 0) return null; return [(x / ww * 0.5 + 0.5) * w, (1 - (y / ww * 0.5 + 0.5)) * h];
    };
    Camera.prototype.orbit = function (dx, dy) {
        this.yaw -= dx * 0.008; this.pitch = M.clamp(this.pitch + dy * 0.008, -1.553, 1.553);
    };
    Camera.prototype.pan = function (dx, dy) {
        const s = this.dist * 0.0016, cy = Math.cos(this.yaw), sy = Math.sin(this.yaw);
        const sp = Math.sin(this.pitch), cp = Math.cos(this.pitch);
        // Translate along camera right and camera up, including vertical movement.
        this.target[0] += (sy * dx - cy * sp * dy) * s;
        this.target[1] += (-cy * dx - sy * sp * dy) * s;
        this.target[2] += cp * dy * s;
    };
    Camera.prototype.zoom = function (f) { this.dist = M.clamp(this.dist * f, 0.15, 160); };
    const VS = 'attribute vec3 aPos;attribute vec3 aNrm;attribute vec2 aUv;uniform mat4 uVP;varying vec3 vN;varying vec2 vUv;varying vec3 vW;void main(){vN=aNrm;vUv=aUv;vW=aPos;gl_Position=uVP*vec4(aPos,1.0);}';
    // uClip: x, y of the centre, squared radius (0 = no clip), highest z that is drawn; used to look into an imported model
    const FS = 'precision mediump float;uniform sampler2D uTex;uniform vec3 uSun;uniform vec4 uTint;uniform vec4 uClip;uniform int uInteriorLightCount;uniform vec4 uInteriorLightPos[8];uniform vec4 uInteriorLightColor[8];varying vec3 vN;varying vec2 vUv;varying vec3 vW;void main(){if(uClip.z>0.0){vec2 q=vW.xy-uClip.xy;if(dot(q,q)>uClip.z||vW.z>uClip.w)discard;}vec4 t=texture2D(uTex,vUv);vec3 n=normalize(vN);float d=max(dot(n,uSun),0.0);float l=0.50+0.42*d+0.10*max(n.z,0.0);vec3 illumination=vec3(l);for(int i=0;i<8;i++){if(i>=uInteriorLightCount)break;vec3 delta=uInteriorLightPos[i].xyz-vW;float distance=length(delta),atten=max(0.,1.-distance/max(.1,uInteriorLightPos[i].w));float diffuse=max(.04,dot(n,delta/max(.01,distance)));illumination+=uInteriorLightColor[i].rgb*uInteriorLightColor[i].w*atten*atten*diffuse*.35;}vec3 color=t.rgb*illumination*uTint.rgb;if(uInteriorLightCount>0)color=vec3(1.)-exp(-color*1.35);gl_FragColor=vec4(color,uTint.a);}';

    const VS2 = 'attribute vec3 aPos;attribute vec4 aCol;uniform mat4 uVP;varying vec4 vC;void main(){vC=aCol;gl_Position=uVP*vec4(aPos,1.0);}';
    const FS2 = 'precision mediump float;varying vec4 vC;void main(){gl_FragColor=vC;}';

    function Renderer(canvas, options) {
        this.world = !!(options && options.world);
        const gl = this.gl = canvas.getContext('webgl', { antialias: true, alpha: false, preserveDrawingBuffer: true });
        if (!gl) throw new Error('WebGL is not available');
        this.s3tc = this.world ? gl.getExtension('WEBGL_compressed_texture_s3tc') : null;
        this.bptc = this.world ? gl.getExtension('EXT_texture_compression_bptc') : null;
        this.derivatives = this.world ? gl.getExtension('OES_standard_derivatives') : null;
        this.aniso = this.world ? gl.getExtension('EXT_texture_filter_anisotropic') : null;
        this.maxAnisotropy = this.aniso ? Math.min(8, gl.getParameter(this.aniso.MAX_TEXTURE_MAX_ANISOTROPY_EXT)) : 1;
        this.canvas = canvas; this.camera = new Camera();
        const mk = (vs, fs) => {
            const p = gl.createProgram();
            [[gl.VERTEX_SHADER, vs], [gl.FRAGMENT_SHADER, fs]].forEach(s => { const sh = gl.createShader(s[0]); gl.shaderSource(sh, s[1]); gl.compileShader(sh); if (!gl.getShaderParameter(sh, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(sh)); gl.attachShader(p, sh); });
            gl.linkProgram(p); if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p)); return p;
        };
        this.pLit = mk(this.world?((options&&options.worldShared)?M.WorldShaders.vertexSource(!!options.worldInstanced):M.WorldShaders.vs):VS, this.world?M.WorldShaders.fragmentSource(!!this.derivatives):FS); this.pFlat = mk(VS2, FS2);
        const L = this.lit = { aPos: gl.getAttribLocation(this.pLit, 'aPos'), aNrm: gl.getAttribLocation(this.pLit, 'aNrm'), aUv: gl.getAttribLocation(this.pLit, 'aUv'), uVP: gl.getUniformLocation(this.pLit, 'uVP'), uTex: gl.getUniformLocation(this.pLit, 'uTex'), uSun: gl.getUniformLocation(this.pLit, 'uSun'), uTint: gl.getUniformLocation(this.pLit, 'uTint'), uClip: gl.getUniformLocation(this.pLit, 'uClip') };
        if(this.world) M.WorldShaders.init(this);
        else { for(const name of ['uInteriorLightCount','uInteriorLightPos[0]','uInteriorLightColor[0]'])L[name]=gl.getUniformLocation(this.pLit,name);this.interiorLightPos=new Float32Array(32);this.interiorLightColor=new Float32Array(32); }

        this.flat = { aPos: gl.getAttribLocation(this.pFlat, 'aPos'), aCol: gl.getAttribLocation(this.pFlat, 'aCol'), uVP: gl.getUniformLocation(this.pFlat, 'uVP') };
        this.white = gl.createTexture(); gl.bindTexture(gl.TEXTURE_2D, this.white);
        gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([255, 255, 255, 255]));
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.NEAREST);
        this.bufs = []; this.mbufs = []; this.clip = null; this.gridBuf = null; this.gridCount = 0; this.statics = {};
        this.ovTris = []; this.ovLines = []; this.ovTopTris = []; this.ovTopLines = []; this.ovBuf = gl.createBuffer();
        this.clear = [0.12, 0.12, 0.12];
        const sun = [-0.45, -0.6, 0.66], sl = Math.hypot(sun[0], sun[1], sun[2]); this.sun = sun.map(v => v / sl);
        this.resize();
    }

    Renderer.prototype.resize = function () {
        const c = this.canvas, dpr = Math.min(window.devicePixelRatio || 1, 2), w = Math.max(2, Math.floor(c.clientWidth * dpr)), h = Math.max(2, Math.floor(c.clientHeight * dpr));
        if (c.width !== w || c.height !== h) { c.width = w; c.height = h; }
    };

    Renderer.prototype.makeBufs = function (batches) {
        const gl = this.gl;
        return batches.map(b => {
            const nv = b.pos.length / 3, stride=this.world?18:8, data = new Float32Array(nv * stride);
            for (let i = 0; i < nv; i++) {const o=i*stride,p=i*3,u=i*2;data[o]=b.pos[p];data[o+1]=b.pos[p+1];data[o+2]=b.pos[p+2];data[o+3]=b.nrm[p];data[o+4]=b.nrm[p+1];data[o+5]=b.nrm[p+2];data[o+6]=b.uv[u];data[o+7]=b.uv[u+1];if(this.world){data[o+8]=b.uv1?.[u]??b.uv[u];data[o+9]=b.uv1?.[u+1]??b.uv[u+1];for(let a=0;a<4;a++){data[o+10+a]=b.col?.[i*4+a]??1;data[o+14+a]=b.col1?.[i*4+a]??0;}}}
            const vb = gl.createBuffer(), ib = gl.createBuffer();
            gl.bindBuffer(gl.ARRAY_BUFFER, vb); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW);
            gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, ib); gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, b.idx, gl.STATIC_DRAW);
            return { vb, ib, count: b.idx.length, b };
        });
    };
    Renderer.prototype.setBatches = function (batches) {
        const gl = this.gl;
        this.bufs.forEach(b => { gl.deleteBuffer(b.vb); gl.deleteBuffer(b.ib); });
        this.bufs = this.makeBufs(batches);
    };
    // the imported model lives apart from the interior so editing the interior does not re-upload it
    Renderer.prototype.setModelBatches = function (batches) {
        const gl = this.gl;
        this.mbufs.forEach(b => { gl.deleteBuffer(b.vb); gl.deleteBuffer(b.ib); });
        this.mbufs = this.makeBufs(batches);
    };
    // GTA often ends its DXT chain at 4 texels on the short axis. WebGL1 needs
    // every level down to 1x1 to enable mip filtering. Only synthesize that tiny tail.
    function completeWorldMips(t) {
        const levels=t.mips.slice(),last=levels[levels.length-1];if(last.w===1&&last.h===1)return levels;
        const dxt1=t.format==='D3DFMT_DXT1',dxt3=t.format==='D3DFMT_DXT3',block=dxt1?8:16,data=last.data;
        let w=last.w,h=last.h,pixels=new Uint8Array(w*h*4);
        const rgb=n=>[Math.round((n>>11&31)*255/31),Math.round((n>>5&63)*255/63),Math.round((n&31)*255/31)];
        for(let by=0;by<Math.ceil(h/4);by++)for(let bx=0;bx<Math.ceil(w/4);bx++){
            const o=(by*Math.ceil(w/4)+bx)*block,c=o+(dxt1?0:8),c0=data[c]|data[c+1]<<8,c1=data[c+2]|data[c+3]<<8,palette=[rgb(c0),rgb(c1)],four=!dxt1||c0>c1;
            palette.push(palette[0].map((v,a)=>four?(2*v+palette[1][a])/3:(v+palette[1][a])/2),four?palette[0].map((v,a)=>(v+2*palette[1][a])/3):[0,0,0]);
            const ids=(data[c+4]|data[c+5]<<8|data[c+6]<<16|data[c+7]<<24)>>>0,alpha=[data[o],data[o+1]];let alphaBits=0;
            if(!dxt1&&!dxt3){for(let i=0;i<6;i++)alphaBits+=data[o+2+i]*2**(8*i);if(alpha[0]>alpha[1])for(let i=1;i<=6;i++)alpha.push(((7-i)*alpha[0]+i*alpha[1])/7);else{for(let i=1;i<=4;i++)alpha.push(((5-i)*alpha[0]+i*alpha[1])/5);alpha.push(0,255);}}
            for(let y=0;y<4;y++)for(let x=0;x<4;x++){const px=bx*4+x,py=by*4+y;if(px>=w||py>=h)continue;const k=y*4+x,id=ids>>>(k*2)&3,j=(py*w+px)*4;let a=255;if(dxt1&&!four&&id===3)a=0;else if(dxt3)a=(data[o+(k>>1)]>>((k&1)*4)&15)*17;else if(!dxt1)a=alpha[Math.floor(alphaBits/2**(k*3))&7];for(let n=0;n<3;n++)pixels[j+n]=palette[id][n];pixels[j+3]=a;}
        }
        while(w>1||h>1){const nw=Math.max(1,w>>1),nh=Math.max(1,h>>1),next=new Uint8Array(nw*nh*4);
            for(let y=0;y<nh;y++)for(let x=0;x<nw;x++){const sum=[0,0,0,0];let count=0;for(let dy=0;dy<2;dy++)for(let dx=0;dx<2;dx++){const i=(Math.min(h-1,y*2+dy)*w+Math.min(w-1,x*2+dx))*4,a=pixels[i+3];for(let c=0;c<3;c++)sum[c]+=pixels[i+c]*a;sum[3]+=a;count++;}const j=(y*nw+x)*4;for(let c=0;c<3;c++)next[j+c]=sum[3]?Math.round(sum[c]/sum[3]):0;next[j+3]=Math.round(sum[3]/count);}
            const encoded=new Uint8Array(Math.ceil(nw/4)*Math.ceil(nh/4)*block);
            for(let by=0;by<Math.ceil(nh/4);by++)for(let bx=0;bx<Math.ceil(nw/4);bx++){const sum=[0,0,0,0];let count=0;for(let y=by*4;y<Math.min(nh,by*4+4);y++)for(let x=bx*4;x<Math.min(nw,bx*4+4);x++){const i=(y*nw+x)*4;for(let c=0;c<4;c++)sum[c]+=next[i+c];count++;}const avg=sum.map(v=>Math.round(v/count)),o=(by*Math.ceil(nw/4)+bx)*block,c=o+(dxt1?0:8),color=(Math.round(avg[0]*31/255)<<11)|(Math.round(avg[1]*63/255)<<5)|Math.round(avg[2]*31/255);encoded[c]=encoded[c+2]=color&255;encoded[c+1]=encoded[c+3]=color>>8;if(dxt1&&avg[3]<128)encoded.fill(255,c+4,c+8);else if(dxt3)encoded.fill(Math.round(avg[3]/17)*17,o,o+8);else if(!dxt1)encoded[o]=encoded[o+1]=avg[3];}
            levels.push({w:nw,h:nh,data:encoded});pixels=next;w=nw;h=nh;
        }
        return levels;
    }
    Renderer.completeWorldMips=completeWorldMips;

    // image textures (from imported .ytd files) keyed by name
    Renderer.prototype.imgTexture = function (key) {
        const M2 = this.imageSource || M.ImportModel; if (!M2 || !M2.textures[key]) return null;
        this.imgTex = this.imgTex || {}; if (this.imgTex[key]) return this.imgTex[key];
        const gl = this.gl, t = M2.textures[key], tx = gl.createTexture(), pot = (t.w & (t.w - 1)) === 0 && (t.h & (t.h - 1)) === 0;
        gl.bindTexture(gl.TEXTURE_2D, tx);
        let complete = pot;
        if(t.mips && t.format==='D3DFMT_BC7'){
            if(this.bptc){const mips=t.mips.slice();let last=mips[mips.length-1];while((last.w>1||last.h>1)&&last.w<=4&&last.h<=4){last={w:Math.max(1,last.w>>1),h:Math.max(1,last.h>>1),data:last.data.subarray(0,16)};mips.push(last);}for(let i=0;i<mips.length;i++){const m=mips[i];gl.compressedTexImage2D(gl.TEXTURE_2D,i,this.bptc.COMPRESSED_RGBA_BPTC_UNORM_EXT,m.w,m.h,0,m.data);}complete=pot&&last.w===1&&last.h===1;}else{gl.texImage2D(gl.TEXTURE_2D,0,gl.RGBA,1,1,0,gl.RGBA,gl.UNSIGNED_BYTE,new Uint8Array([160,160,160,255]));complete=false;}
        } else if (t.mips && this.s3tc) {
            const format = this.s3tc['COMPRESSED_RGBA_S3TC_' + t.format.replace('D3DFMT_', '') + '_EXT'];
            const mips=completeWorldMips(t);mips.forEach((m,i)=>gl.compressedTexImage2D(gl.TEXTURE_2D,i,format,m.w,m.h,0,m.data));
            const last=mips[mips.length-1];complete=pot&&last.w===1&&last.h===1;
        } else {
            gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, t.w, t.h, 0, gl.RGBA, gl.UNSIGNED_BYTE, t.rgba);
            if(pot)gl.generateMipmap(gl.TEXTURE_2D);
        }
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, complete ? gl.LINEAR_MIPMAP_LINEAR : gl.LINEAR);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, pot ? gl.REPEAT : gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, pot ? gl.REPEAT : gl.CLAMP_TO_EDGE);
        gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
        if(this.aniso)gl.texParameterf(gl.TEXTURE_2D,this.aniso.TEXTURE_MAX_ANISOTROPY_EXT,this.maxAnisotropy);
        return (this.imgTex[key] = tx);
    };
    Renderer.prototype.resetImgTextures = function () { const gl = this.gl; if (this.imgTex) for (const k in this.imgTex) gl.deleteTexture(this.imgTex[k]); this.imgTex = {}; };

    Renderer.prototype.setGrid = function (z, ext, cx, cy) {
        const gl = this.gl, v = [], x0 = cx - ext, x1 = cx + ext, y0 = cy - ext, y1 = cy + ext;
        const col = (major) => major ? [0.62, 0.70, 0.86, 0.34] : [0.62, 0.70, 0.86, 0.14];
        for (let i = x0; i <= x1; i++) { const c = col(i % 5 === 0); v.push(i, y0, z, ...c, i, y1, z, ...c); }
        for (let j = y0; j <= y1; j++) { const c = col(j % 5 === 0); v.push(x0, j, z, ...c, x1, j, z, ...c); }
        if (!this.gridBuf) this.gridBuf = gl.createBuffer();
        gl.bindBuffer(gl.ARRAY_BUFFER, this.gridBuf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(v), gl.STATIC_DRAW); this.gridCount = v.length / 7;
    };

    // line sets that stay the same between frames (the vanilla collision outline); positions = x,y,z pairs
    Renderer.prototype.setStaticLines = function (name, pos, color, on) {
        const gl = this.gl; if (!this.statics) this.statics = {};
        let s = this.statics[name]; if (!s) s = this.statics[name] = { buf: gl.createBuffer(), count: 0, on: false };
        const n = pos ? pos.length / 3 : 0, data = new Float32Array(n * 7);
        for (let i = 0; i < n; i++) { data[i * 7] = pos[i * 3]; data[i * 7 + 1] = pos[i * 3 + 1]; data[i * 7 + 2] = pos[i * 3 + 2]; data[i * 7 + 3] = color[0]; data[i * 7 + 4] = color[1]; data[i * 7 + 5] = color[2]; data[i * 7 + 6] = color[3]; }
        gl.bindBuffer(gl.ARRAY_BUFFER, s.buf); gl.bufferData(gl.ARRAY_BUFFER, data, gl.STATIC_DRAW); s.count = n; s.on = !!on;
    };
    Renderer.prototype.staticOn = function (name, on) { if (this.statics && this.statics[name]) this.statics[name].on = !!on; };

    // ---- overlays (rebuilt every frame by the tools) ----
    Renderer.prototype.ovClear = function () { this.ovTris.length = 0; this.ovLines.length = 0; this.ovTopTris.length = 0; this.ovTopLines.length = 0; };
    // the "top" overlay ignores depth, so a gizmo is never hidden by walls (like the transform gizmos in Blender)
    Renderer.prototype.ovTopQuad = function (a, b, c, d, col) { const t = this.ovTopTris; [a, b, c, a, c, d].forEach(p => t.push(p[0], p[1], p[2], col[0], col[1], col[2], col[3])); };
    Renderer.prototype.ovTopLine = function (a, b, col) { this.ovTopLines.push(a[0], a[1], a[2], col[0], col[1], col[2], col[3], b[0], b[1], b[2], col[0], col[1], col[2], col[3]); };
    Renderer.prototype.ovQuad = function (a, b, c, d, col) { const t = this.ovTris; [a, b, c, a, c, d].forEach(p => t.push(p[0], p[1], p[2], col[0], col[1], col[2], col[3])); };
    Renderer.prototype.ovLine = function (a, b, col) { this.ovLines.push(a[0], a[1], a[2], col[0], col[1], col[2], col[3], b[0], b[1], b[2], col[0], col[1], col[2], col[3]); };
    Renderer.prototype.ovBox = function (mn, mx, col, edgeCol) {
        const [x0, y0, z0] = mn, [x1, y1, z1] = mx, q = (a, b, c, d) => this.ovQuad(a, b, c, d, col);
        q([x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1]); q([x0, y1, z0], [x0, y0, z0], [x0, y0, z1], [x0, y1, z1]);
        q([x1, y1, z0], [x0, y1, z0], [x0, y1, z1], [x1, y1, z1]); q([x0, y0, z0], [x1, y0, z0], [x1, y0, z1], [x0, y0, z1]);
        q([x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]); q([x0, y1, z0], [x1, y1, z0], [x1, y0, z0], [x0, y0, z0]);
        if (edgeCol) {
            const c = [[x0, y0, z0], [x1, y0, z0], [x1, y1, z0], [x0, y1, z0], [x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]];
            [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]].forEach(e => this.ovLine(c[e[0]], c[e[1]], edgeCol));
        }
    };

    // an oriented box: centre c, half sizes along its width (hu), depth (hn) and height (hz), turned by yaw about Z
    Renderer.prototype.ovOBox = function (c, hu, hn, hz, yaw, col, edgeCol) {
        const ux = Math.cos(yaw), uy = Math.sin(yaw), nx = -Math.sin(yaw), ny = Math.cos(yaw);
        const P = (su, sn, sz) => [c[0] + su * hu * ux + sn * hn * nx, c[1] + su * hu * uy + sn * hn * ny, c[2] + sz * hz];
        const v = [P(-1, -1, -1), P(1, -1, -1), P(1, 1, -1), P(-1, 1, -1), P(-1, -1, 1), P(1, -1, 1), P(1, 1, 1), P(-1, 1, 1)];
        if (col) [[0, 1, 2, 3], [4, 5, 6, 7], [0, 1, 5, 4], [1, 2, 6, 5], [2, 3, 7, 6], [3, 0, 4, 7]].forEach(f => this.ovQuad(v[f[0]], v[f[1]], v[f[2]], v[f[3]], col));
        if (edgeCol) [[0, 1], [1, 2], [2, 3], [3, 0], [4, 5], [5, 6], [6, 7], [7, 4], [0, 4], [1, 5], [2, 6], [3, 7]].forEach(e => this.ovLine(v[e[0]], v[e[1]], edgeCol));
    };

    // filter(batch) -> bool; tint(batch) -> [r,g,b,a] optional
    Renderer.prototype.render = function (filter) {
        const gl = this.gl, cam = this.camera; this.resize();if(this.world)this._lastWorldMaterial=null;
        gl.viewport(0, 0, this.canvas.width, this.canvas.height);
        cam.update(this.canvas.width / this.canvas.height);
        gl.clearColor(this.clear[0], this.clear[1], this.clear[2], 1); gl.clear(gl.COLOR_BUFFER_BIT | gl.DEPTH_BUFFER_BIT);
        gl.enable(gl.DEPTH_TEST); gl.depthFunc(gl.LEQUAL); gl.enable(gl.CULL_FACE); gl.cullFace(gl.BACK);

        const localLights=!this.world&&M.InteriorLights?M.InteriorLights.previewLights().sort((a,b)=>Math.hypot(a.x-cam.target[0],a.y-cam.target[1],a.z-cam.target[2])-Math.hypot(b.x-cam.target[0],b.y-cam.target[1],b.z-cam.target[2])).slice(0,8):[];
        if(!this.world){this.interiorLightPos.fill(0);this.interiorLightColor.fill(0);localLights.forEach((l,i)=>{this.interiorLightPos.set([l.x,l.y,l.z,l.falloff],i*4);this.interiorLightColor.set([l.r/255,l.g/255,l.b/255,l.intensity],i*4);});}
        const L = this.lit, drawBatches = (glassPass) => {
            gl.useProgram(this.pLit); gl.uniformMatrix4fv(L.uVP, false, cam.vp); gl.uniform3fv(L.uSun, this.sun); gl.uniform1i(L.uTex, 0);
            if(!this.world){gl.uniform1i(L.uInteriorLightCount,localLights.length);gl.uniform4fv(L['uInteriorLightPos[0]'],this.interiorLightPos);gl.uniform4fv(L['uInteriorLightColor[0]'],this.interiorLightColor);}
            gl.enableVertexAttribArray(L.aPos); gl.enableVertexAttribArray(L.aNrm); gl.enableVertexAttribArray(L.aUv);if(this.world)for(const a of [L.aUv1,L.aColor,L.aColor1])if(a>=0)gl.enableVertexAttribArray(a);
            const cl = this.clip;
            for (const list of [this.bufs, this.mbufs]) for (const o of list) {
                const b = o.b, trans = !!b.glass || !!b.blend || (b.alpha != null && b.alpha < 1); if (trans !== glassPass || !filter(b)) continue;
                gl.activeTexture(gl.TEXTURE0);
                if (b.clip && cl) gl.uniform4f(L.uClip, cl.cx, cl.cy, cl.r * cl.r, cl.zmax); else gl.uniform4f(L.uClip, 0, 0, 0, 0);
                const al = b.alpha != null ? b.alpha : 1;
                if (this.world) M.WorldShaders.bind(this,b);
                else if (b.glass) { const gt = b.imgKey && this.imgTexture(b.imgKey); gl.bindTexture(gl.TEXTURE_2D, gt || this.white); if (gt) gl.uniform4f(L.uTint, 1, 1, 1, al); else gl.uniform4f(L.uTint, 0.62, 0.78, 0.92, b.alpha != null ? al : 0.30); }
                else if (b.imgKey && this.imgTexture(b.imgKey)) { gl.bindTexture(gl.TEXTURE_2D, this.imgTexture(b.imgKey)); gl.uniform4f(L.uTint, 1, 1, 1, al); }
                else if (b.flat) { gl.bindTexture(gl.TEXTURE_2D, this.white); gl.uniform4f(L.uTint, b.flat[0], b.flat[1], b.flat[2], al); }
                else { gl.bindTexture(gl.TEXTURE_2D, TEX.glTexture(gl, b.tex)); gl.uniform4f(L.uTint, 1, 1, 1, 1); }
                if (b.noCull) gl.disable(gl.CULL_FACE); else gl.enable(gl.CULL_FACE);
                gl.bindBuffer(gl.ARRAY_BUFFER, o.vb); gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, o.ib);
                const stride=this.world?72:32;gl.vertexAttribPointer(L.aPos,3,gl.FLOAT,false,stride,0);gl.vertexAttribPointer(L.aNrm,3,gl.FLOAT,false,stride,12);gl.vertexAttribPointer(L.aUv,2,gl.FLOAT,false,stride,24);if(this.world){gl.vertexAttribPointer(L.aUv1,2,gl.FLOAT,false,72,32);gl.vertexAttribPointer(L.aColor,4,gl.FLOAT,false,72,40);gl.vertexAttribPointer(L.aColor1,4,gl.FLOAT,false,72,56);if(b.decal){gl.enable(gl.POLYGON_OFFSET_FILL);gl.polygonOffset(-1,-1);}else gl.disable(gl.POLYGON_OFFSET_FILL);}
                gl.drawElements(gl.TRIANGLES, o.count, gl.UNSIGNED_SHORT, 0);if(this.world)gl.disable(gl.POLYGON_OFFSET_FILL);
            }
            gl.disableVertexAttribArray(L.aNrm); gl.disableVertexAttribArray(L.aUv);if(this.world)for(const a of [L.aUv1,L.aColor,L.aColor1])if(a>=0)gl.disableVertexAttribArray(a);
        };
        gl.disable(gl.BLEND); drawBatches(false);

        // grid, glass and overlays: no depth writes
        const F = this.flat; gl.enable(gl.BLEND); gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA); gl.depthMask(false); gl.disable(gl.CULL_FACE);
        gl.enable(gl.CULL_FACE); drawBatches(true); gl.disable(gl.CULL_FACE);
        gl.useProgram(this.pFlat); gl.uniformMatrix4fv(F.uVP, false, cam.vp); gl.enableVertexAttribArray(F.aPos); gl.enableVertexAttribArray(F.aCol);
        const drawFlat = (buf, mode, count) => {
            gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.vertexAttribPointer(F.aPos, 3, gl.FLOAT, false, 28, 0); gl.vertexAttribPointer(F.aCol, 4, gl.FLOAT, false, 28, 12); gl.drawArrays(mode, 0, count);
        };
        if (M.Model.state.showHelperLines === true && this.gridBuf && this.showGrid !== false) drawFlat(this.gridBuf, gl.LINES, this.gridCount);
        for (const k in this.statics) { const s = this.statics[k]; if (s.on && M.Model.state.showHelperLines === true) drawFlat(s.buf, gl.LINES, s.count); }
        if (this.ovTris.length) { gl.bindBuffer(gl.ARRAY_BUFFER, this.ovBuf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.ovTris), gl.DYNAMIC_DRAW); drawFlat(this.ovBuf, gl.TRIANGLES, this.ovTris.length / 7); }
        if (this.ovLines.length && M.Model.state.showHelperLines === true) { gl.bindBuffer(gl.ARRAY_BUFFER, this.ovBuf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.ovLines), gl.DYNAMIC_DRAW); drawFlat(this.ovBuf, gl.LINES, this.ovLines.length / 7); }
        if (this.ovTopTris.length || this.ovTopLines.length) {
            gl.disable(gl.DEPTH_TEST);
            if (this.ovTopTris.length) { gl.bindBuffer(gl.ARRAY_BUFFER, this.ovBuf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.ovTopTris), gl.DYNAMIC_DRAW); drawFlat(this.ovBuf, gl.TRIANGLES, this.ovTopTris.length / 7); }
            if (this.ovTopLines.length) { gl.bindBuffer(gl.ARRAY_BUFFER, this.ovBuf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array(this.ovTopLines), gl.DYNAMIC_DRAW); drawFlat(this.ovBuf, gl.LINES, this.ovTopLines.length / 7); }
            gl.enable(gl.DEPTH_TEST);
        }
        gl.disableVertexAttribArray(F.aCol); gl.depthMask(true);
    };

    M.Renderer = Renderer; M.Camera = Camera;
})(window.MLO);
