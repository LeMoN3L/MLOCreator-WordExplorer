// Packed placement data is parsed in a worker; only new placements become objects.
(function(M){'use strict';
 function decode(data,known=new Map()){
  if(!data.sceneBuffer)return data;const {sceneBuffer:buffer,sceneOffset:offset,recordCount:count,entityCount,ancestorCount,ids,prototypes}=data;
  if(data.sceneFormat!==1||data.stride!==80||count<0||entityCount<0||entityCount>count||ancestorCount<0||offset+count*80+ancestorCount*4>buffer.byteLength)throw Error('Invalid world placement packet');
  const floats=new Float32Array(buffer,offset,count*20),words=new Uint32Array(buffer,offset,count*20),parents=new Uint32Array(buffer,offset+count*80,ancestorCount),entities=[],fallbacks=[];
  for(let i=0;i<count;i++){
   const at=i*20,id=ids[words[at]];if(typeof id!=='string')throw Error('Invalid world placement identifier');let e=known.get(id);
   if(!e){const prototype=prototypes[words[at+1]],start=words[at+2],length=words[at+3];if(!prototype||start+length>parents.length)throw Error('Invalid world placement ancestry');const ancestors=[];for(let n=start;n<start+length;n++){const parent=ids[parents[n]];if(typeof parent!=='string')throw Error('Invalid world parent identifier');ancestors.push(parent);}
    e={...prototype,id,ancestors,pos:[floats[at+4],floats[at+5],floats[at+6]],rot:[floats[at+7],floats[at+8],floats[at+9],floats[at+10]],scale:[floats[at+11],floats[at+12],floats[at+13]],min:[floats[at+14],floats[at+15],floats[at+16]],max:[floats[at+17],floats[at+18],floats[at+19]]};
   }
   (i<entityCount?entities:fallbacks).push(e);
  }
  const result={...data,entities,fallbacks};for(const key of ['sceneBuffer','sceneOffset','ids','prototypes','recordCount','entityCount','ancestorCount','stride','sceneFormat'])delete result[key];return result;
 }
 M.WorldScene={decode};
})(window.MLO);
