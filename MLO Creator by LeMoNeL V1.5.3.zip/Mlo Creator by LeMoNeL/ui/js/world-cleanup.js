﻿// Persistent object removals and selectable map lights. No per-frame work when disabled.
(function(M){'use strict';
 // Matching DLC copies share one marker and are selected/deleted together.
 // Persistence and export retain all original source identities.
 M.groupWorldLights=function(items){
  const groups=[],cells=new Map(),seen=new Set(),epsilon=.02;
  for(const light of items){
   if(seen.has(light.id))continue;seen.add(light.id);
   const cell=light.pos.map(v=>Math.floor(v/epsilon)),prefix=light.hash+'|'+light.type+'|';let group=null,best=epsilon;
   for(let x=-1;x<=1;x++)for(let y=-1;y<=1;y++)for(let z=-1;z<=1;z++){
    const bucket=cells.get(prefix+[cell[0]+x,cell[1]+y,cell[2]+z].join('|'));
    for(const candidate of bucket||[]){const d=Math.hypot(...light.pos.map((v,a)=>v-candidate.pos[a]));
     if(d<=best&&Math.hypot(...(light.direction||[0,0,0]).map((v,a)=>v-(candidate.members[0].direction||[0,0,0])[a]))<.001){group=candidate;best=d;}
    }
   }
   if(!group){group={pos:light.pos,members:[]};groups.push(group);const key=prefix+cell.join('|');if(!cells.has(key))cells.set(key,[]);cells.get(key).push(group);}
   group.members.push(light);
  }
  return groups;
 };
 const entryText=n=>n+(n===1?' light entry':' light entries');
 const positionText=n=>n+(n===1?' position':' positions');
 M.createWorldCleanup=function(C){
  const {el}=M,clone=x=>JSON.parse(JSON.stringify(x)),selected=new Set();
  let state={version:1,baseResource:'',props:[],lights:[]},ready=false,busy=false,lights=[],anchor=null,lastQuery=0,request=0,abort=null,lightMode=false,querying=false,groups=[],activeLightId=null,exporting=false,exportPhase='',exportResult=null,exportFailure='';
  let exportFolder='';try{exportFolder=localStorage.getItem('mlo.worldLightExportFolder')||'';}catch{}
  const error=e=>{C.say(e.message||String(e),true);M.UI.toast(e.message||String(e),'err');};
  const removed=()=>new Set(state.lights.map(e=>e.id));
  const rebuildGroups=()=>{groups=M.groupWorldLights(lights);const gone=removed();for(const group of groups)if(group.members.some(l=>selected.has(l.id)))for(const light of group.members)if(!gone.has(light.id))selected.add(light.id);};
  const selectedBulbs=()=>M.groupWorldLights(selectedEntries());
  const selectedEntries=()=>{const gone=removed();return lights.filter(l=>selected.has(l.id)&&!gone.has(l.id));};
  function sync(old={props:[]}){for(const e of old.props)C.hidden.delete(e.id);for(const e of state.props)C.hidden.add(e.id);C.dirty();C.inspector();}
  async function load(){try{const s=await C.api('world/cleanup/state');const old=state;state=s;ready=true;sync(old);}catch(e){error(e);}}
  async function commit(next,record=true){
   if(!ready){error(new Error('World edits are still loading. Please try again in a moment.'));return false;}if(busy||exporting)return false;
   busy=true;C.inspector();const before=clone(state);
   try{const s=await C.api('world/cleanup/set','POST',next);if(JSON.stringify(s.lights)!==JSON.stringify(before.lights)||s.baseResource!==before.baseResource){exportResult=null;exportFailure='';}state=s;if(state.baseResource!==before.baseResource){selected.clear();lights=[];groups=[];activeLightId=null;}sync(before);C.editsChanged?.();if(record)C.history({kind:'cleanup',before,after:clone(state)});anchor=null;return true;}
   catch(e){error(e);return false;}finally{busy=false;C.inspector();}
  }
  async function query(pos,radius=180){
   const token=++request;abort?.abort();abort=new AbortController();querying=true;
   try{const r=await C.api('world/cleanup/lights','POST',{x:pos[0],y:pos[1],z:pos[2],radius},abort.signal);if(token!==request)return false;const incoming=new Set(r.lights.map(e=>e.id));lights=[...r.lights,...lights.filter(e=>selected.has(e.id)&&!incoming.has(e.id))];rebuildGroups();anchor=pos.slice();C.inspector();C.dirty();return true;}
   catch(e){if(e.name!=='AbortError')error(e);return false;}finally{if(token===request)querying=false;}
  }
  function mode(t){lightMode=t==='lights';if(!lightMode){selected.clear();activeLightId=null;}else{C.selected.clear();C.clearHover();anchor=null;}C.inspector();C.dirty();}
  function tick(now){if(!lightMode||!C.active()||!ready||busy||querying||!C.renderer())return;const p=C.renderer().camera.pos;if(now-lastQuery<1300)return;if(anchor&&Math.hypot(...p.map((v,a)=>v-anchor[a]))<50)return;lastQuery=now;query(p);}
  function project(light){const R=C.renderer(),cv=C.canvas();return R?.camera.project(light.pos,cv.clientWidth,cv.clientHeight);}
  function draw(){
   if(!lightMode)return;const R=C.renderer(),cv=C.canvas(),gone=removed();if(!R)return;
   const f=R.camera.forward(),right=[Math.sin(R.camera.yaw),-Math.cos(R.camera.yaw),0],up=[right[1]*f[2],-right[0]*f[2],right[0]*f[1]-right[1]*f[0]];
   for(const group of groups){const members=group.members.filter(l=>!gone.has(l.id));if(!members.length)continue;const l=members[0],p=project(l);if(!p||p[0]<-15||p[1]<-15||p[0]>cv.clientWidth+15||p[1]>cv.clientHeight+15)continue;
    const radius=Math.max(.12,Math.min(2,Math.hypot(...l.pos.map((v,a)=>v-R.camera.pos[a]))*.008));
    // Marker colors describe workspace selection, not saved YMAP light flags.
    const col=members.some(e=>selected.has(e.id))?[1,.35,.14,1]:[1,.8,.25,1];
    const at=(x,y)=>l.pos.map((v,a)=>v+(right[a]*x+up[a]*y)*radius);
    for(let k=0;k<12;k++){const a=k*Math.PI/6,b=(k+1)*Math.PI/6;R.ovTopLine(at(Math.cos(a),Math.sin(a)),at(Math.cos(b),Math.sin(b)),col);}
    R.ovTopLine(at(-1.3,0),at(1.3,0),col);R.ovTopLine(at(0,-1.3),at(0,1.3),col);
   }
  }
  function pick(x,y,shift){
   if(!lightMode)return false;if(busy||exporting)return true;
   const rect=C.canvas().getBoundingClientRect();x-=rect.left;y-=rect.top;let hit=null,best=14;const gone=removed();
   for(const group of groups){const members=group.members.filter(l=>!gone.has(l.id));if(!members.length)continue;const p=project(members[0]);if(!p)continue;const d=Math.hypot(x-p[0],y-p[1]);if(d<best){best=d;hit=members;}}
   const toggleOff=shift&&hit&&hit.every(l=>selected.has(l.id));if(!shift)selected.clear();
   activeLightId=hit?.[0]?.id||null;if(hit)for(const light of hit){if(toggleOff)selected.delete(light.id);else selected.add(light.id);}
   C.inspector();C.dirty();return true;
  }
  async function removeLights(){
   if(busy||exporting||!selected.size)return;const bulbs=selectedBulbs().length,next=clone(state),ids=new Set(next.lights.map(e=>e.id));
   for(const light of lights)if(selected.has(light.id)&&!ids.has(light.id)){next.lights.push(light);ids.add(light.id);}
   if(next.lights.length===state.lights.length)return;
   if(await commit(next)){selected.clear();activeLightId=null;C.inspector();C.say(bulbs+(bulbs===1?' light removed.':' lights removed.')+' All matching map copies are included. Choose Export to save.');}
  }
  async function removeProps(){if(busy||exporting)return;const items=[...C.selected].map(id=>C.entities.get(id)).filter(Boolean);if(!items.length)return;const next=clone(state),ids=new Set(next.props.map(e=>e.id));for(const e of items)if(!ids.has(e.id))next.props.push(e);if(await commit(next)){C.selected.clear();C.clearHover();C.inspector();C.say(items.length+' objects removed. Ctrl+Z restores them; open Export settings to export a FiveM resource.');}}
  function lightsPanel(panel){
   const count=selectedBulbs().length,removedCount=M.groupWorldLights(state.lights).length,body=C.sidebarSection(panel,'Lights','lights',count?count+' selected':removedCount?removedCount+' removed':'');
   const choose=C.button('Select lights',()=>C.tool('lights'));choose.classList.add('we-select-lights');choose.classList.toggle('on',lightMode);choose.disabled=busy||exporting;
   body.append(choose,el('p',{class:'note'},'Click a bulb to select it with all its overlapping map copies. Shift+click selects more.'),el('p',{class:'we-light-count'},count+(count===1?' light selected':' lights selected')));
   const remove=C.button(busy?'Deleting…':'Delete',removeLights);remove.classList.add('we-delete-lights','we-remove');remove.disabled=busy||exporting||!count;
   const save=C.button(exporting?exportPhase:'Export',finishSetup);save.classList.add('primary','we-export-lights');save.disabled=busy||exporting||!ready||!state.lights.length;save.setAttribute('aria-busy',String(exporting));
   body.append(el('div',{class:'we-light-actions'},remove,save),el('p',{class:'note'},removedCount+(removedCount===1?' light removed':' lights removed')));
   if(exportFailure)body.append(el('p',{class:'we-cleanup-warning'},exportFailure));
   if(exportResult){body.append(el('p',{class:'we-world-export-status'},'Export complete'),el('p',{class:'we-light-export-path'},exportResult.folder),C.button('Open folder',()=>C.api('world/cleanup/open-output','POST',{}).catch(error)));}
   body.append(el('div',{class:'we-light-legend'},el('span',null,el('i',{class:'we-marker-unselected'}),'Unselected'),el('span',null,el('i',{class:'we-marker-selected'}),'Selected')));
   const advanced=el('details',{class:'we-light-advanced'},el('summary',null,'Advanced'),C.button('Find light by reference…',lookupDialog),C.button('Export settings',dialog));body.append(advanced);
  }
  function lookupDialog(){const input=el('input',{class:'we-cleanup-path',placeholder:'vw_lodlights_small006.ymap:383'}),info=el('p',{class:'note'},'Uses the original CodeWalker reference, then checks the chosen base resource.'),find=C.button('Find light',async()=>{find.disabled=true;request++;abort?.abort();querying=false;try{const l=await C.api('world/cleanup/lookup','POST',{query:input.value});C.closeDialog();C.tool('lights');if(!lights.some(e=>e.id===l.id))lights.push(l);rebuildGroups();activeLightId=l.id;selected.clear();selected.add(l.id);rebuildGroups();const R=C.renderer();if(R){R.camera.pos=[l.pos[0],l.pos[1]-12,l.pos[2]+6];R.camera.yaw=Math.PI/2;R.camera.pitch=-.4;}anchor=l.pos.slice();lastQuery=performance.now();C.inspector();C.dirty();if(l.absentInBase)C.say('This light is already absent in the base resource.',true);}catch(e){info.textContent=e.message;}finally{find.disabled=false;}});C.showDialog('Find map light',input,info,find);}
  function finishSetup(){
   if(exporting||busy||!state.lights.length)return;
   const resource=C.resourceFolder?.();if(resource){exporting=true;exportPhase='Exporting lights…';C.inspector();C.api('world/cleanup/export-lights','POST',{outputFolder:resource+'\\stream'}).then(r=>{exportResult=r;C.showDialog('Export successful',el('p',null,'Removed lights exported into the active resource.'),el('p',{class:'we-light-export-path'},r.folder));C.say('Light export complete: '+r.folder);}).catch(error).finally(()=>{exporting=false;C.inspector();});return;}

   const input=el('input',{id:'we-export-folder',class:'we-export-folder',type:'text',value:exportFolder,placeholder:'Paste a folder path, for example C:\\Exports',autocomplete:'off',spellcheck:'false'}),info=el('p',{class:'note'},'Lighte Delete will be created or updated here. Previous exported light removals are kept. You can also paste the Lighte Delete path itself.'),ok=C.button('OK',submit);
   async function submit(){
    if(exporting||busy)return;const folder=input.value.trim().replace(/^"(.*)"$/,'$1').trim();
    if(!folder){info.textContent='Paste the destination folder path.';info.classList.add('we-cleanup-warning');input.focus();return;}
    exportFolder=folder;exporting=true;exportPhase='Exporting lights…';exportFailure='';ok.disabled=true;input.disabled=true;info.textContent='Saving YMAP files…';info.classList.remove('we-cleanup-warning');C.inspector();
    try{
     exportResult=await C.api('world/cleanup/export-lights','POST',{outputFolder:folder});
     try{localStorage.setItem('mlo.worldLightExportFolder',folder);}catch{}
     C.say('Light export complete: '+exportResult.folder);C.closeDialog();exportSuccess(exportResult);
    }catch(e){exportFailure=e.message||String(e);info.textContent=exportFailure;info.classList.add('we-cleanup-warning');C.say(exportFailure,true);}
    finally{exporting=false;exportPhase='';ok.disabled=false;input.disabled=false;C.inspector();}
   }
   input.addEventListener('keydown',event=>{if(event.key==='Enter'){event.preventDefault();submit();}});
   ok.classList.add('primary');const shade=C.showDialog('Export removed lights',el('label',{for:'we-export-folder',class:'note'},'Destination folder'),input,info,ok);shade.querySelector('.we-dialog').classList.add('we-export-path-dialog');input.focus();input.select();
  }
  function exportSuccess(result){
   const open=C.button('Open folder',()=>C.api('world/cleanup/open-output','POST',{}).catch(error));open.classList.add('primary');
   const shade=C.showDialog('Export successful',el('span',{class:'we-export-check','aria-hidden':'true'},'✓'),el('p',null,result.files.length+' YMAP files were saved successfully.'),el('p',{class:'we-light-export-path'},result.folder),el('p',{class:'note'},'Copy Lighte Delete into your map resource’s stream folder. Restore to default resets this workspace; your exported files stay saved.'),open);shade.querySelector('.we-dialog').classList.add('we-export-success');
  }
  async function resetWorldEdits(){
   if(exporting||busy||!ready)return false;
   const before={cleanup:clone(state),workspace:C.workspaceSnapshot()},next=clone(state);next.props=[];next.lights=[];
   if(!await commit(next,false))return false;
   request++;abort?.abort();querying=false;lastQuery=0;selected.clear();activeLightId=null;exportResult=null;exportFailure='';await C.restoreWorkspace({offsets:[],hidden:[],collisions:[]});await C.resetMap?.();
   const after={cleanup:clone(state),workspace:C.workspaceSnapshot()};C.history({kind:'world-reset',before,after});anchor=null;C.inspector();C.dirty();C.say('Restored to default. Removed lights, objects and object moves are restored. Exported files are unchanged.');M.UI.toast('Restored to default. Exported files kept.');return true;
  }
  function canReset(){const workspace=C.workspaceSnapshot();return ready&&!!(state.lights.length||state.props.length||workspace.offsets.length||workspace.hidden.length||workspace.editor?.added?.length||workspace.collisions?.length);}
  function dialog(){
   const base=el('input',{class:'we-cleanup-path',value:state.baseResource,placeholder:'Existing resource folder containing fxmanifest.lua'}),info=el('p',{class:'note'},'Optional source for preserving map edits. Existing Lighte Delete exports are always retained.'),save=C.button('Use source resource',async()=>{const next=clone(state);next.baseResource=base.value;save.disabled=true;if(await commit(next))info.textContent='Source resource saved.';save.disabled=false;});
   const parts=[el('label',{class:'note'},'Source resource (optional)'),base,save,info];
   if(state.props.length){const status=el('p',{class:'note'}),objects=C.button('Export resource with objects',async()=>{objects.disabled=true;try{const r=await C.api('world/cleanup/export','POST',{});status.textContent='Exported to '+r.folder;}catch(e){status.textContent=e.message;}finally{objects.disabled=false;}});parts.push(objects,status);}
   C.showDialog('Export settings',...parts);
  }
  function focus(){if(!lightMode||!selected.size)return false;const list=lights.filter(e=>selected.has(e.id));if(!list.length)return false;const p=[0,1,2].map(a=>list.reduce((n,e)=>n+e.pos[a],0)/list.length),R=C.renderer();R.camera.pos=[p[0],p[1]-12,p[2]+6];R.camera.yaw=Math.PI/2;R.camera.pitch=-.4;C.dirty();return true;}
  const initialLoad=load();
  async function replaceProjectEdits(props,lights){await initialLoad;const next=clone(state);next.props=props;next.lights=lights;return commit(next,false);}
  return {ready:()=>initialLoad,replaceProjectEdits,tick,draw,mode,pick,focus,lightsPanel,resetWorldEdits,canReset,remove:()=>lightMode?removeLights():removeProps(),restore:s=>commit(s,false),sync:()=>sync(),clearSelection(){selected.clear();activeLightId=null;},busy:()=>busy||exporting,pause(){request++;querying=false;abort?.abort();},getState:()=>clone(state),dialog};
 };
})(window.MLO);
