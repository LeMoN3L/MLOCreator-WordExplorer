// GTA materials with optional world environment lighting; thumbnails retain studio lighting.
(function(M){'use strict';
 const vs=`attribute vec3 aPos;attribute vec3 aNrm;attribute vec2 aUv;attribute vec2 aUv1;attribute vec4 aColor;attribute vec4 aColor1;uniform mat4 uVP;uniform mat4 uShadowVP0;uniform mat4 uShadowVP1;varying vec3 vN;varying vec2 vUv;varying vec2 vUv1;varying vec4 vColor;varying vec4 vColor1;varying vec3 vWorld;varying vec4 vShadow0;varying vec4 vShadow1;void main(){vN=aNrm;vUv=aUv;vUv1=aUv1;vColor=aColor;vColor1=aColor1;vWorld=aPos;vShadow0=uShadowVP0*vec4(vWorld,1.0);vShadow1=uShadowVP1*vec4(vWorld,1.0);gl_Position=uVP*vec4(vWorld,1.0);}`;
 const fs=`#ifdef GL_FRAGMENT_PRECISION_HIGH
precision highp float;
#else
precision mediump float;
#endif
uniform sampler2D uTex;uniform sampler2D uTex1;uniform sampler2D uTex2;uniform sampler2D uTex3;uniform sampler2D uTex4;uniform sampler2D uMask;uniform sampler2D uShadow;
uniform vec3 uSun;uniform vec4 uTint;uniform vec4 uMaterial;uniform float uHasMask;uniform float uDiffuse2;uniform float uEnvironment;uniform vec3 uSunColor;uniform vec3 uAmbientUp;uniform vec3 uAmbientDown;uniform vec3 uEye;uniform vec3 uFogColor;uniform float uFogDensity;uniform float uWet;uniform float uNight;uniform vec4 uShadowParams;uniform int uPointCount;uniform vec4 uPointPos[8];uniform vec4 uPointColor[8];uniform vec4 uPointDir[8];
varying vec3 vN;varying vec2 vUv;varying vec2 vUv1;varying vec4 vColor;varying vec4 vColor1;varying vec3 vWorld;varying vec4 vShadow0;varying vec4 vShadow1;
float shadowSample(vec2 uv,float depth,vec2 center,vec2 gradient){vec2 texel=uShadowParams.yz;vec2 actual=(floor(uv/texel)+.5)*texel;vec2 delta=actual-center;delta.x*=2.0;float compare=depth+dot(gradient,delta);return step(compare,dot(texture2D(uShadow,actual),vec4(0.0000000603086294,0.0000153787005,0.00392156863,1.0)));}
float shadowAt(vec4 position,float tile,vec3 normal,float ndl){vec3 p=position.xyz/position.w*.5+.5;if(p.x<.015||p.x>.985||p.y<.015||p.y>.985||p.z<0.0||p.z>1.0)return -1.0;vec2 uv=vec2(p.x*.5+tile*.5,p.y),s=uShadowParams.yz;vec3 right=normalize(cross(abs(uSun.z)>.98?vec3(0,1,0):vec3(0,0,1),uSun)),up=cross(uSun,right);vec2 gradient=vec2(dot(normal,right),dot(normal,up))/max(3.0*dot(normal,uSun),.025);
#ifdef WORLD_RECEIVER_DERIVATIVES
float bias=.000025+.00002*(1.0-ndl);
#else
// A conservative depth-only fallback for older WebGL implementations.
gradient=vec2(0.0);float bias=.00008+.0012*(1.0-ndl);
#endif
float z=p.z-bias;float v=shadowSample(uv+vec2(-.65,-.65)*s,z,uv,gradient)+shadowSample(uv+vec2(.65,-.65)*s,z,uv,gradient)+shadowSample(uv+vec2(-.65,.65)*s,z,uv,gradient)+shadowSample(uv+vec2(.65,.65)*s,z,uv,gradient);return v*.25;}

void main(){
// GTA shading normals may be smoothed or deliberately bent on grass. Shadows
// need the actual receiver plane; evaluate derivatives before alpha discard.
vec3 receiverNormal=normalize(vN);
#ifdef WORLD_RECEIVER_DERIVATIVES
if(uEnvironment>.5){vec3 plane=cross(dFdx(vWorld),dFdy(vWorld));float area=dot(plane,plane);if(area>1.e-14){receiverNormal=plane*inversesqrt(area);if(dot(receiverNormal,vN)<0.0)receiverNormal=-receiverNormal;}}
#endif
vec4 t=texture2D(uTex,vUv);if(uMaterial.x>0.5){vec4 m=vColor1;if(uHasMask>0.5)m=texture2D(uMask,vUv1);vec4 w=uMaterial.x>1.5?m:mix(m,vColor1,vColor.a);vec4 a=mix(texture2D(uTex1,vUv),texture2D(uTex2,vUv),clamp(w.b,0.0,1.0));vec4 b=mix(texture2D(uTex3,vUv),texture2D(uTex4,vUv),clamp(w.b,0.0,1.0));t=mix(a,b,clamp(w.g,0.0,1.0));t.a=1.0;}else{if(uDiffuse2>0.5){vec4 b=texture2D(uTex1,vUv1);t=mix(t,b,b.a);}if(uMaterial.y>0.5){t.a*=vColor.a;if(t.a<0.01)discard;}else{if(t.a<0.33)discard;t.a=1.0;}}
vec3 n=normalize(vN);float ndl=max(dot(n,uSun),0.0);vec3 color;
if(uEnvironment<.5){float light=.57+.36*ndl+.07*max(n.z,0.0);color=t.rgb*uTint.rgb*light;}else{
float visibility=1.0;if(uShadowParams.w>.5&&ndl>.001){visibility=shadowAt(vShadow0,0.0,receiverNormal,ndl);if(visibility<0.0)visibility=shadowAt(vShadow1,1.0,receiverNormal,ndl);visibility=visibility<0.0?1.0:mix(1.0,visibility,uShadowParams.x);}
vec3 lighting=mix(uAmbientDown,uAmbientUp,clamp(n.z*.5+.5,0.0,1.0))+uSunColor*ndl*visibility;
for(int i=0;i<8;i++){if(i>=uPointCount)break;vec3 delta=uPointPos[i].xyz-vWorld;float distance=length(delta),radius=uPointPos[i].w;vec3 direction=delta/max(distance,.001);float attenuation=pow(max(1.0-distance/radius,0.0),2.0)*6.0/(1.0+.05*distance*distance);float cone=uPointDir[i].w<-.9?1.0:smoothstep(uPointDir[i].w,uPointColor[i].w,dot(-direction,uPointDir[i].xyz));lighting+=uPointColor[i].rgb*max(dot(n,direction),0.0)*attenuation*cone;}
lighting=mix(lighting,vec3(1.6),uMaterial.z*mix(.55,1.0,uNight));color=pow(max(t.rgb*uTint.rgb,vec3(0.0)),vec3(2.2))*lighting*(1.0-uWet*.12*max(n.z,0.0));vec3 view=normalize(uEye-vWorld),halfway=normalize(view+uSun);color+=uSunColor*pow(max(dot(n,halfway),0.0),64.0)*uWet*.75*max(n.z,0.0)*visibility;float fog=clamp(1.0-exp(-length(uEye-vWorld)*uFogDensity),0.0,.97);color=mix(color,pow(max(uFogColor,vec3(0.0)),vec3(2.2)),fog);color=color/(vec3(1.0)+max(color-vec3(1.0),vec3(0.0)));color=pow(max(color,vec3(0.0)),vec3(1.0/2.2));}
gl_FragColor=vec4(color,t.a*uTint.a);}`;
 function init(R){const gl=R.gl,L=R.lit;for(const name of ['aUv1','aColor','aColor1'])L[name]=gl.getAttribLocation(R.pLit,name);for(const name of ['uTex1','uTex2','uTex3','uTex4','uMask','uMaterial','uHasMask','uDiffuse2','uEnvironment','uSunColor','uAmbientUp','uAmbientDown','uEye','uFogColor','uFogDensity','uWet','uNight','uShadow','uShadowVP0','uShadowVP1','uShadowParams','uPointCount','uPointPos[0]','uPointColor[0]','uPointDir[0]'])L[name]=gl.getUniformLocation(R.pLit,name);gl.useProgram(R.pLit);['uTex','uTex1','uTex2','uTex3','uTex4','uMask','uShadow'].forEach((name,i)=>gl.uniform1i(L[name],i));}
 function bind(R,b){
  if(b.materialKey&&R._lastWorldMaterial===b.materialKey)return;R._lastWorldMaterial=b.materialKey;const gl=R.gl,L=R.lit,s=b.samplers||{},terrain=/terrain/i.test(b.shader||''),first=s.TextureSampler_layer0||b.imgKey,tex=key=>key&&R.imgTexture(key)||R.white;
  const keys=terrain?[b.imgKey,first,s.TextureSampler_layer1||first,s.TextureSampler_layer2||first,s.TextureSampler_layer3||first,s.lookupSampler||s.TextureSampler_mask]:[b.imgKey,s.DiffuseSampler2];
  R._boundWorldTextures=R._boundWorldTextures||[];for(let i=0;i<keys.length;i++){if(i===1&&!terrain&&!keys[i])continue;const texture=tex(keys[i]);if(R._boundWorldTextures[i]===texture)continue;if(R._activeWorldUnit!==i){gl.activeTexture(gl.TEXTURE0+i);R._activeWorldUnit=i;}gl.bindTexture(gl.TEXTURE_2D,texture);R._boundWorldTextures[i]=texture;}
  const hasTexture=!!R.imageSource.textures[b.imgKey]||terrain,tint=[hasTexture?1:.64,hasTexture?1:.62,hasTexture?1:.57,b.alpha??1],material=[terrain?(/_cm/.test(b.shader)?2:1):0,b.decal?1:0,/emissive|neon/i.test(b.shader||'')?1:0,0],hasMask=keys[5]&&R.imageSource.textures[keys[5]]?1:0,diffuse2=!terrain&&s.DiffuseSampler2?1:0;
  const same=(a,c)=>a&&a.every((n,i)=>n===c[i]);if(!same(R._worldTint,tint)){gl.uniform4f(L.uTint,...tint);R._worldTint=tint;}if(!same(R._worldMaterial,material)){gl.uniform4f(L.uMaterial,...material);R._worldMaterial=material;}if(R._worldHasMask!==hasMask){gl.uniform1f(L.uHasMask,hasMask);R._worldHasMask=hasMask;}if(R._worldDiffuse2!==diffuse2){gl.uniform1f(L.uDiffuse2,diffuse2);R._worldDiffuse2=diffuse2;}
 }
 function vertexSource(instanced){return vs.replace('uniform mat4 uVP;',(instanced?'attribute vec3 aTranslation;attribute vec4 aRotation;attribute vec3 aScale;':'uniform vec3 uTranslation;uniform vec4 uRotation;uniform vec3 uScale;')+'uniform mat4 uVP;').replace('void main(){vN=aNrm;','vec3 rotateQ(vec3 p,vec4 q){return p+2.0*cross(q.xyz,cross(q.xyz,p)+q.w*p);}void main(){vec3 scale='+(instanced?'aScale':'uScale')+';vec4 rotation='+(instanced?'aRotation':'uRotation')+';vec3 translation='+(instanced?'aTranslation':'uTranslation')+';vN=rotateQ(aNrm/scale,rotation);').replace('vWorld=aPos;','vWorld=rotateQ(aPos*scale,rotation)+translation;');}
 function fragmentSource(derivatives){return (derivatives?'#extension GL_OES_standard_derivatives : enable\n#define WORLD_RECEIVER_DERIVATIVES\n':'')+fs;}
 M.WorldShaders={vs,fs,init,bind,vertexSource,fragmentSource};
})(window.MLO);
