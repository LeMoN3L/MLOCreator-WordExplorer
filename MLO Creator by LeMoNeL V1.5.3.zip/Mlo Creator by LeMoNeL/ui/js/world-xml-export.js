(function(M){'use strict';
 M.createWorldXmlExport=function(C){
  const {el}=M;let busy=false,lastResult=null,folder='',parts={object:true,textures:true,ymap:true};
  try{folder=localStorage.getItem('mlo.worldXmlExportFolder')||'';const stored=JSON.parse(localStorage.getItem('mlo.worldXmlExportParts')||'null');if(stored)for(const key of Object.keys(parts))if(typeof stored[key]==='boolean')parts[key]=stored[key];}catch{}
  const selected=()=>C.selection();
  const valid=()=>{const items=selected();return !!items.length&&items.every(e=>e?.quality==='HD'||e?.quality==='LOD')&&Object.values(parts).some(Boolean);};
  function render(panel){
   const body=C.sidebarSection(panel,'Export','export'),disabled=busy||C.locked();
   const controls=[];const save=C.button(busy?'Exporting…':'Export to XML',open);save.classList.add('primary','we-export-xml');save.disabled=disabled||!valid();
   for(const [key,label,hint]of [['object','Object','.ydr.xml / .yft.xml'],['textures','Textures','.ytd.xml + DDS'],['ymap','YMAP','.ymap.xml']]){
    const input=el('input',{type:'checkbox','data-xml-part':key});input.checked=parts[key];input.disabled=disabled;
    input.addEventListener('change',()=>{parts[key]=input.checked;try{localStorage.setItem('mlo.worldXmlExportParts',JSON.stringify(parts));}catch{}save.disabled=busy||C.locked()||!valid();});controls.push(input);
    body.append(el('label',{class:'we-xml-option'},input,el('span',null,label),el('small',null,hint)));
   }
   body.append(save,el('p',{class:'note we-property-description'},'Export only the checked parts of the selected objects. YMAP contains its original source map.'));
   if(lastResult)body.append(el('p',{class:'we-world-export-status'},'XML export complete'),el('p',{class:'we-light-export-path'},lastResult.folder));
  }
  function open(){
   if(busy||C.locked()||!valid())return;
   const items=selected().map(e=>({id:e.id})),chosen={...parts},input=el('input',{class:'we-export-folder',id:'we-xml-folder',value:folder,placeholder:'Paste the destination folder path',spellcheck:'false',autocomplete:'off'}),info=el('p',{class:'note'},'A new selection folder will be created here. Existing exports are kept.'),ok=C.button('Export',submit);
   async function submit(){
    if(busy||C.locked())return;const path=input.value.trim().replace(/^"(.*)"$/,'$1').trim();if(!path){info.textContent='Paste the destination folder path.';input.focus();return;}
    busy=true;ok.disabled=true;input.disabled=true;info.textContent='Exporting selected files…';C.changed();
    try{
     lastResult=await C.api('world/export-xml','POST',{entities:items,parts:chosen,outputFolder:path});folder=path;try{localStorage.setItem('mlo.worldXmlExportFolder',path);}catch{}
     C.closeDialog();const details=lastResult.objects+' models · '+lastResult.textureDictionaries+' texture dictionaries · '+lastResult.ymaps+' YMAPs';
     const warnings=el('div',{class:'we-xml-warnings'});for(const warning of lastResult.warnings||[])warnings.append(el('p',{class:'note'},String(warning)));
     C.showDialog('XML export complete',el('span',{class:'we-export-check','aria-hidden':'true'},'✓'),el('p',null,details),el('p',{class:'we-light-export-path'},lastResult.folder),warnings,C.button('Open folder',()=>C.api('world/xml-open','POST',{}).catch(e=>M.UI.toast(e.message,'err'))));
    }catch(e){info.textContent=e.message||String(e);info.classList.add('we-cleanup-warning');}
    finally{busy=false;ok.disabled=false;input.disabled=false;C.changed();}
   }
   input.addEventListener('keydown',e=>{if(e.key==='Enter'){e.preventDefault();submit();}});ok.classList.add('primary');C.showDialog('Export to XML',el('p',{class:'note'},Object.entries(chosen).filter(([,yes])=>yes).map(([key])=>key==='ymap'?'YMAP':key[0].toUpperCase()+key.slice(1)).join(' + ')),el('label',{for:'we-xml-folder',class:'note'},'Destination folder'),input,info,ok);input.focus();input.select();
  }
  return {render,busy:()=>busy};
 };
})(window.MLO);
