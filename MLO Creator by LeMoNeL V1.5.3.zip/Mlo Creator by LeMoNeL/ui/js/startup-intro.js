// One lightweight introduction per page launch. The editor starts behind it.
(function(M){'use strict';
 const root=document.getElementById('startup-intro');if(!root)return;root.focus({preventScroll:true});
 const skip=document.getElementById('intro-skip');
 let dismissed=false,leaving=false,minimumTimer=0,removeTimer=0,paintFrame=0,started=null,appReady=false,arrivalTimer=0,arrivingHome=null;
 const escapeKeys=new Set(['Escape','Enter',' ']);
 function remove(){if(dismissed)return;dismissed=true;clearTimeout(minimumTimer);clearTimeout(removeTimer);clearTimeout(safetyTimer);cancelAnimationFrame(paintFrame);root.remove();window.removeEventListener('keydown',onKey,true);window.removeEventListener('error',onError,true);window.removeEventListener('unhandledrejection',onFailure);if(document.activeElement===document.body)document.querySelector('#workspace-home button')?.focus({preventScroll:true});M.Intro={visible:false,ready(){},dismiss(){}};}
 function resetHome(){clearTimeout(arrivalTimer);arrivalTimer=0;if(arrivingHome){arrivingHome.classList.remove('intro-arriving');arrivingHome=null;}}
 function enterHome(){arrivingHome=document.querySelector('#workspace-home');if(!arrivingHome||arrivingHome.hidden){arrivingHome=null;return;}arrivingHome.classList.add('intro-arriving');arrivalTimer=setTimeout(resetHome,1700);}
 function dismiss(immediate=false){if(dismissed||(leaving&&!immediate))return;leaving=true;clearTimeout(minimumTimer);if(immediate){resetHome();remove();return;}enterHome();root.classList.add('is-leaving');removeTimer=setTimeout(remove,1150);}
 function schedule(){if(dismissed||leaving||!appReady||started===null)return;clearTimeout(minimumTimer);minimumTimer=setTimeout(()=>dismiss(),Math.max(0,5000-(performance.now()-started)));}
 function ready(){appReady=true;schedule();}
 function onKey(e){if(dismissed)return;if(escapeKeys.has(e.key)){e.preventDefault();e.stopImmediatePropagation();dismiss(true);}else if(e.key==='Tab'){e.preventDefault();e.stopImmediatePropagation();skip.focus({preventScroll:true});}else{e.preventDefault();e.stopImmediatePropagation();}}
 function onError(e){if(e.error||e.message||e.target?.tagName==='SCRIPT')dismiss(true);}
 function onFailure(){dismiss(true);}
 // Start the five-second hold after the browser has had a frame to paint the intro.
 const safetyTimer=setTimeout(()=>dismiss(true),12000);
 paintFrame=requestAnimationFrame(()=>{paintFrame=requestAnimationFrame(()=>{paintFrame=0;if(dismissed)return;root.classList.add('is-playing');started=performance.now();schedule();});});
 skip.addEventListener('click',()=>dismiss(true));window.addEventListener('keydown',onKey,true);window.addEventListener('error',onError,true);window.addEventListener('unhandledrejection',onFailure);
 M.Intro={ready,dismiss:()=>dismiss(true),get visible(){return !dismissed;}};
})(window.MLO=window.MLO||{});
