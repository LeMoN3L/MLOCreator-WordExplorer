// Native LOD coverage with reusable topology and bounded per-update allocations.
(function(M){'use strict';
 const LOAD_RADIUS=2000,KEEP_RADIUS=2300;
 const ranks={HD:0,LOD:1,SLOD1:2,SLOD2:3,SLOD3:4,SLOD4:5};
 function level(e){const raw=(e?.lod||'').replace('LODTYPES_DEPTH_','');return raw||((e?.quality==='HD')?'HD':'LOD');}
 function allowed(e,max='ORPHANHD'){if(!e)return false;const l=level(e);return max==='ORPHANHD'||(l!=='ORPHANHD'&&(ranks[l]??-1)>=(ranks[max]??0));}
 function limit(entities,ids,max='ORPHANHD'){const out=new Set();for(const id of ids){const e=entities.get(id);if(!e)continue;if(allowed(e,max)){out.add(id);continue;}if(level(e)==='ORPHANHD')continue;for(const parent of e.ancestors||[]){if(allowed(entities.get(parent),max)){out.add(parent);break;}}}return out;}
 function distance(e,pos,off){
  if(!e?.min||!e?.max)return Infinity;
  const x=off?.[0]||0,y=off?.[1]||0,z=off?.[2]||0;
  const dx=Math.max(e.min[0]+x-pos[0],0,pos[0]-e.max[0]-x),dy=Math.max(e.min[1]+y-pos[1],0,pos[1]-e.max[1]-y),dz=Math.max(e.min[2]+z-pos[2],0,pos[2]-e.max[2]-z);
  return Math.sqrt(dx*dx+dy*dy+dz*dz);
 }
 function index(entities,ids){return plan(entities,ids,[]);}
 function radial(entities,ids,pos,selected,hidden,retained,offsets,cachedIndex,maxLod='ORPHANHD'){
  const targets=new Set(),files=new Map(),inside=new Set(),distances=new Map();
  for(const id of limit(entities,ids,maxLod)){const e=entities.get(id);if(!e||hidden.has(id))continue;const d=distance(e,pos,offsets.get(id));distances.set(id,d);if(selected.has(id)||d<=LOAD_RADIUS||(d<=KEEP_RADIUS&&retained.has(e.file)))inside.add(id);}
  const tree=cachedIndex||index(entities,distances.keys());
  function mark(n){let active=distances.has(n.id),near=inside.has(n.id);for(const child of n.children){mark(child);active=active||child.active;near=near||child.near;}n.active=active;n.near=near;}
  function collect(n){
   if(!n.active)return;const e=entities.get(n.id);if(!allowed(e,maxLod))return;
   if(!n.near&&/SLOD[34]/.test(e.lod||'')){targets.add(n.id);return;}
   if(n.target&&distances.has(n.id)){if(inside.has(n.id)||/SLOD[234]/.test(e.lod||''))targets.add(n.id);return;}
   for(const child of n.children)collect(child);
  }
  for(const root of tree.roots){mark(root);collect(root);}
  for(const id of selected)if(allowed(entities.get(id),maxLod)&&!hidden.has(id))targets.add(id);
  for(const id of targets){const e=entities.get(id),d=selected.has(id)?0:(distances.get(id)??distance(e,pos,offsets.get(id)));files.set(e.file,Math.min(files.get(e.file)??Infinity,d));}
  return {targets,files};
 }
 function plan(entities,targets,previous){
  const nodes=new Map(),roots=new Set(),legacy=new Map();
  const node=id=>{let n=nodes.get(id);if(!n){n={id,children:new Set(),target:false};nodes.set(id,n);}return n;};
  for(const id of targets){const e=entities.get(id);if(!e)continue;let parent=null;const ancestors=e.ancestors||[];
   for(let i=ancestors.length-1;i>=0;i--){const key=ancestors[i];if(!entities.has(key))continue;const n=node(key);if(parent)parent.children.add(n);else roots.add(n);parent=n;}
   const n=node(id);if(parent)parent.children.add(n);else roots.add(n);n.target=true;
  }
  for(const id of previous){const e=entities.get(id);if(!e)continue;for(const parent of e.ancestors||[]){let list=legacy.get(parent);if(!list){list=[];legacy.set(parent,list);}list.push(id);}}
  return {nodes,roots,legacy};
 }
 function resolve(p,ready,unavailable){
  let pending=0;const blocked=new Set(),ids=[];
  function visit(n){
   const start=ids.length;
   if(n.target){
    if(ready(n.id)){ids.push(n.id);return true;}if(unavailable(n.id))return true;
    pending++;blocked.add(n.id);for(const id of p.legacy.get(n.id)||[])if(ready(id))ids.push(id);return ids.length>start;
   }
   let covered=true;for(const child of n.children)if(!visit(child))covered=false;
   if(covered)return true;if(ready(n.id)){ids.length=start;ids.push(n.id);return true;}return false;
  }
  for(const root of p.roots)visit(root);return {ids:new Set(ids),pending,blocked};
 }
 M.WorldStreaming={plan,resolve,radial,index,distance,level,allowed,limit,LOAD_RADIUS,KEEP_RADIUS};
})(typeof window==='undefined'?module.exports:window.MLO);
